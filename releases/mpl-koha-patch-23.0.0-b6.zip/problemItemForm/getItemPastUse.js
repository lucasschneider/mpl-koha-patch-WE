(function(){
  'use strict';
  let pastUse = document.querySelector('[id^="tag_952_subfield_Z_"');

  if (pastUse) {
    return pastUse.value ? pastUse.value : 0;
  }
})();
